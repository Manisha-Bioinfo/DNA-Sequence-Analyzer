
def gc_content(seq):
    gc = seq.count('G') + seq.count('C')
    return round(gc / len(seq) * 100, 2)

def nucleotide_frequency(seq):
    return {nuc: seq.count(nuc) for nuc in 'ATGC'}

def transcribe(seq):
    return seq.replace('T', 'U')

def reverse_complement(seq):
    mapping = str.maketrans('ATGC', 'TACG')
    return seq.translate(mapping)[::-1]

def find_motif(seq, motif):
    positions = []
    for i in range(len(seq) - len(motif) + 1):
        if seq[i:i+len(motif)] == motif:
            positions.append(i + 1)
    return positions
