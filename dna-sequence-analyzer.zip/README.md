# 🧬 DNA Sequence Analyzer

A simple Python tool to analyze DNA sequences:
- GC content
- Nucleotide frequency
- DNA to RNA transcription
- Reverse complement
- Motif search

## 🔧 How to Use
```bash
pip install -r requirements.txt
jupyter notebook notebooks/demo.ipynb
```
